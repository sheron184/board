
export function bucket_fill(){
	console.log("yo");
}